from pl_bolts.models.detection.components.torchvision_backbones import create_torchvision_backbone

__all__ = ["create_torchvision_backbone"]
