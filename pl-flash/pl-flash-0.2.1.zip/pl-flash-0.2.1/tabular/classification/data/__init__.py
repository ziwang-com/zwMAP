from flash.tabular.classification.data.data import TabularData
