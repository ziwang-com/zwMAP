from flash.vision.detection.data import ObjectDetectionData
from flash.vision.detection.model import ObjectDetector
