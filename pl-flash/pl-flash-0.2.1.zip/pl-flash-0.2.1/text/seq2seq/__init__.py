from flash.text.seq2seq.core import Seq2SeqData, Seq2SeqFreezeEmbeddings, Seq2SeqTask
from flash.text.seq2seq.summarization import SummarizationData, SummarizationTask
from flash.text.seq2seq.translation import TranslationData, TranslationTask
